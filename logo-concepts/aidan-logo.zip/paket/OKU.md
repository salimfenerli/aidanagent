# Aidan logo — 3 konsept

Referans dilinde: iki renk, geometrik, bol negatif alan, siyah zemin.

## Renkler
| Rol | Hex | Not |
|---|---|---|
| Zemin (koyu) | `#0A0908` | Markanın `--bg` (#121211) ile aynı sıcak ailede |
| İşaret (koyu zeminde) | `#E9E8E4` | Kırık beyaz |
| İşaret (açık zeminde) | `#121211` | Kömür |
| Vurgu | `#FB7D24` | Turuncu — her iki zeminde de aynı |

⚠️ **Vurgu, UI accent'i (`--accent: #e08a63` terracotta) DEĞİL.** Terracotta
denendi, 32px'te kayboluyor ve kırık beyazla ayrışmıyor. Logo daha doygun bir
turuncu istiyor; terracotta arayüzde kalsın. İkisi aynı sıcak ailede olduğu için
çakışmıyorlar.

## Dosyalar (her konsept için)
| Dosya | Nerede |
|---|---|
| `aidan-<ad>.svg` | Ana işaret, koyu zemin |
| `aidan-<ad>-acik.svg` | Açık zemin sürümü (kömür halka) |
| `aidan-<ad>-ikon.svg` | App ikonu, yuvarlatılmış kare |
| `aidan-<ad>-maskable.svg` | PWA maskable — iç %76 güvenli alan |
| `aidan-<ad>-kilit.svg` | Yatay kilit (işaret + Aidan) |
| `aidan-<ad>-kilit-acik.svg` | Kilit, açık zemin |
| `aidan-<ad>-icon-1024.png` | Üretim, `icon.png` yerine |
| `aidan-<ad>-maskable-1024.png` | Üretim, `icon-maskable.png` yerine |

## Kurulum (seçtikten sonra)
1. `aidan-<ad>-ikon.svg` → `icon.svg`
2. `aidan-<ad>-icon-1024.png` → `icon.png`
3. `aidan-<ad>-maskable-1024.png` → `icon-maskable.png`
4. `manifest.webmanifest` → `background_color` ve `theme_color`: `#121211`
   (şu an `#0a0b0f` — eski mavi-siyah temadan kalma, DESIGN.md ile çelişiyor)
