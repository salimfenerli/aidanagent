# Aidan logo — vurgu rengi seçenekleri

İşaret sabit: **İlerleme** (halka = ray, renkli yay = ilerleme).
Değişen tek şey vurgu rengi.

| Dosya | Renk | Not |
|---|---|---|
| `r-01-terracotta.svg` | `#E08A63` | Markanın accent'i — kremle ayrışmıyor, 32px'te kayboluyor |
| `r-02-amber.svg` | `#E5A117` | Sıcak altın, zeminle aynı aile · ⚠️ `--warning` ile çakışıyor |
| `r-03-lime.svg` | `#C6F24E` | Asit yeşil, en çok patlayan · **UI token'larıyla çakışmıyor** |
| `r-04-jade.svg` | `#3DBE7C` | Yeşil · ⚠️ `--success` ile çakışıyor |
| `r-05-turkuaz.svg` | `#2ED3C6` | Soğuk — sıcak kömür zemine ters düşüyor |
| `r-06-mavi.svg` | `#4AA8FF` | Soğuk · ⚠️ `--info` ile çakışıyor |
| `r-07-mor.svg` | `#9B7CF6` | AI/teknoloji okuması, spora bağlanmıyor |
| `r-08-fusya.svg` | `#F0459A` | Yüksek enerji, arayüzde eşleştirmesi zor |
| `r-09-kiremit.svg` | `#E2483C` | Dövüş enerjisi · ⚠️ kırmızı = hata okuması |
| `r-10-krem.svg` | `#E9E8E4` | Tek renk — vurgu yok, işaretin iki parçalı fikri kayboluyor |

`t-<renk>-ikon.svg` · `t-<renk>-kilit.svg` · `t-<renk>-kilit-acik.svg`
→ ilk üç aday (amber, lime, jade) için app ikonu ve yatay kilit.

## Sabit kalanlar
| Rol | Hex |
|---|---|
| Zemin (koyu) | `#0A0908` |
| İşaret, koyu zeminde | `#E9E8E4` |
| İşaret, açık zeminde | `#121211` |
